import unittest
from main import soma, subtracao, multiplicacao, divisao

class SomaTest(unittest.TestCase):

    def test_soma(self):
        self.assertEqual(soma(2, 2), 4)
        self.assertEqual(soma(2, 0), 2)

    def test_subtracao(self):
        self.assertEqual(subtracao(6, 3), 3)
        self.assertEqual(subtracao(2, 1), 1)

    def test_multiplicacao(self):
        self.assertEqual(multiplicacao(6, 3), 18)
        self.assertEqual(multiplicacao(2, 1), 2)

    def test_divisao(self):
        self.assertEqual(divisao(6, 3), 2)
        self.assertEqual(divisao(2, 1), 2)